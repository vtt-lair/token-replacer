Save token artwork here for the relevant CR creature.
File name structure should start with the creature name, spaces in creature names should be replace with "_". 
Adding more than one token art for the same creature should have the name of the creature still as the start of the file name eg. "Dire_Wolf_Black.png" and "Dire_Wolf_White.png".